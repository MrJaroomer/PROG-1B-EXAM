package com.mycompany.mattresssalesapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProductTest {
        private final String[] testProducts = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };
        
        private final int[][] testSales = {
            {25, 18, 20},
            {15 ,10, 12},
            {18, 15, 20},
        };
        
        @Test
        public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
            Product product = new Product(testProducts, testSales);
            assertEquals(153, product.GetTotalProductsSold());
        }
        
        @Test
        public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
            Product product = new Product(testProducts, testSales);
            assertEquals(17.0, product.GetAverageProductsSold(), 0.01);
        }
    }