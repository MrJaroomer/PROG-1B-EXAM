package com.mycompany.mattresssalesapp;

import java.util.Scanner;

public class Mattresssalesapp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int[][] sales = new int[3][3];

        // Get sales input for each product
        for (int i = 0; i < products.length; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("Enter number of sales for month " + (j + 1) + " for " + products[i] + " mattress: ");
                sales[i][j] = scanner.nextInt();
            }
            System.out.println();
        }

        int totalSales = 0;
        int totalEntries = 0;
        int highestSale = sales[0][0];
        String mostPopularProduct = products[0];

        // Calculate totals and find the highest sale
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                totalSales += sales[i][j];
                totalEntries++;

                if (sales[i][j] > highestSale) {
                    highestSale = sales[i][j];
                    mostPopularProduct = products[i];
                }
            }
        }

        int averageSales = totalSales / totalEntries;

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("****************************************");
        System.out.println("TOTAL PRODUCT SALES: " + totalSales);
        System.out.println("AVERAGE PRODUCT SALES: " + averageSales);
        System.out.println("MOST POPULAR PRODUCT: " + mostPopularProduct + "(" + highestSale + ")");
        System.out.println("****************************************");

        scanner.close();
    }
}
