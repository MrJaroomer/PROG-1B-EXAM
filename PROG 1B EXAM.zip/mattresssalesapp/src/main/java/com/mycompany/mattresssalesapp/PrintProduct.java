package com.mycompany.mattresssalesapp;

public class PrintProduct {
    private Product product;
            
    public PrintProduct(Product product) {
        this.product = product;
    }
    
    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }
    
    public void printAverageProductSales() {
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductsSold());
    }
    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
    
    public void printFullReport() {
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("****************************************");
        printTotalProductSales();
        printAverageProductSales();
        printMostPopularProduct();
        System.out.println("****************************************");
    }
}