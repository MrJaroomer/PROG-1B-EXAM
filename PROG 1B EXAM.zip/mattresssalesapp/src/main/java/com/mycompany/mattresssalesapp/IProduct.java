package com.mycompany.mattresssalesapp;

public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductsSold();
    String GetMostPopularProduct();
}