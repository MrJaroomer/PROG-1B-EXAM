package com.mycompany.mattresssalesapp;

public class Product implements IProduct {
    private String[] products;
    private int[][] sales;
    
    public Product(String[] products, int[][] sales) {
        this.products = products;
        this.sales = sales;
    }
    
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
        }
        return total;
    }
    
    @Override
    public double GetAverageProductsSold() {
        int total = GetTotalProductsSold();
        int count = 0;
        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length;
        }
        return (double) total / count;
    }
    
    @Override
    public String GetMostPopularProduct() {
        int highestSale = sales[0][0];
        String bestProduct = products[0];
        
        for (int i = 0; i < sales.length; i++) {
            for (int j = 0; j < sales[i].length; j++) {
                if (sales[i][j] > highestSale) {
                    highestSale = sales[i][j];
                    bestProduct = products[i];
                }
            }
        }
        return bestProduct + "(" + highestSale + ")";
    }
}